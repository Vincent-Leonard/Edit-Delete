package com.example.editdelete;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.ArrayList;

public class UserData {
    public static ArrayList<user> DataUser = new ArrayList<>();
}
